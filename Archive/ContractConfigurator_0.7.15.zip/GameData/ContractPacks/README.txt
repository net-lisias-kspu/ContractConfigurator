This directory contains Contract Packs for the Contract Configurator mod, 
available from:
    https://github.com/jrossignol/ContractConfigurator

To see a listing of available Contract Packs, please visit:
    http://forum.kerbalspaceprogram.com/threads/101604
